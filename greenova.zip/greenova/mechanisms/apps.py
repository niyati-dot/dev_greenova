from django.apps import AppConfig


class MechanismsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "mechanisms"
