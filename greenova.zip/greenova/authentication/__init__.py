"""Authentication app for managing user authentication and sessions."""
