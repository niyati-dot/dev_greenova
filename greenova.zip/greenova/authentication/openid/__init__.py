"""
Authentication OpenID integration package.
"""
