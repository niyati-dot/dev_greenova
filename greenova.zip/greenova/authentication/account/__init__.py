"""
Authentication account package.
"""
