"""
Authentication allauth integration package.
"""
