"""
Authentication tests package.
"""
