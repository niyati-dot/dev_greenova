"""Core app package for Greenova."""
