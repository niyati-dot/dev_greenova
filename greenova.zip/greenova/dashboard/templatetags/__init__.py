# This file marks the templatetags directory as a Python package.
